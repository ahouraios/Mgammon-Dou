# راهنمای جامع استقرار، راه‌اندازی PWA و پشتیبان‌گیری در cPanel
## سامانه MGAMMON Duo (حضور، غیاب، کارکرد و امور مالی)

این مستند تمام مراحل استقرار واقعی وب‌اپلیکیشن **MGAMMON Duo** را بر پایه محدودیت‌ها و استانداردهای `Setup Node.js App` ( مبتنی بر Phusion Passenger) و پایگاه داده `MySQL / MariaDB` در هاست اشتراکی **cPanel** شرح می‌دهد.

---

### ۱. ساخت دیتابیس و کاربر MySQL در cPanel
1. وارد پنل هاست **cPanel** خود شوید و از بخش **Databases** گزینه **MySQL® Database Wizard** را باز کنید.
2. یک نام برای دیتابیس وارد کنید (مثلاً `cpaneluser_mgammon_duo`) و روی **Next Step** کلیک کنید.
3. یک نام کاربری دیتابیس (مثلاً `cpaneluser_mgammon`) و یک رمز عبور قوی ایجاد کنید.
4. در مرحله دسترسی‌ها، تیک گزینه **ALL PRIVILEGES** را فعال کرده و روی **Make Changes** کلیک کنید.

---

### ۲. راه‌اندازی ساختار جداول و مهاجرت خودکار (`database/schema.sql`)
1. برنامه در اولین اجرا روی دیتابیس کاملاً خالی، به‌صورت خودکار تمام **۱۴ جدول اصلی** (`schema_migrations`, `users`, `user_sessions`, `attendance_logs`, `historical_work_records`, `daily_work_reports`, `financial_transactions`, `system_settings`, `system_settings_snapshots`, `work_correspondences`, `leave_requests`, `work_tasks`, `user_reminders`, `audit_logs`) را با Encoding استاندارد `utf8mb4_unicode_ci` ایجاد کرده و مهاجرت‌های نسخه‌بندی‌شده (`v1` تا `v6`) را اجرا می‌کند.
2. در صورت تمایل به ایمپورت دستی پیش از اجرا، می‌توانید در **phpMyAdmin** دیتابیس ساخته‌شده را انتخاب کرده و از زبانه **Import** فایل `database/schema.sql` را وارد نمایید.
3. در اولین راه‌اندازی، تنها **دو حساب کاربری اولیه** شامل مدیر (**مجید نورایی** با نقش `manager`) و پرسنل (**امید میثمی** با نقش `worker`) با رمزهای هش‌شده (`bcrypt`) و وضعیت الزام تغییر رمز اولیه (`must_change_password = 1`) به همراه تنظیمات پایه سامانه ایجاد می‌شوند و هیچ داده آزمایشی وارد دیتابیس نمی‌گردد.
4. تنظیمات وب‌سرویس پیامک (**ملی‌پیامک**) در ابتدای راه‌اندازی الزامی نیست و نبودن آن مانع اجرای هیچ‌یک از بخش‌های سامانه نمی‌شود؛ مدیر می‌تواند پس از ورود، از بخش **«تنظیمات سامانه»** مشخصات خط و حساب ملی‌پیامک را ثبت و آزمایش کند.

---

### ۳. تفکیک مرحله ساخت بسته (در محیط توسعه) از محتویات بسته آماده نصب روی هاست

#### الف) مرحله ساخت بسته در پروژه اصلی توسعه (مخصوص محیط توسعه — خارج از هاست cPanel)
- دستور `npm run deploy:package` (به همراه اسکریپت‌های پوشه `scripts/`) **صرفاً یک ابزار توسعه در پروژه اصلی (Development Repository)** است که پیش از انتشار، وظیفه اجرای بررسی‌های تایپ‌اسکریپت (`lint`)، آزمون‌های خودکار (`test`)، کامپایل فرانت‌اند و سرور (`dist/` و `app.cjs`) و تولید فایل فشرده `mgammon-duo-cpanel-deploy.zip` را بر عهده دارد.
- **این دستور و پوشه `scripts/` داخل بسته نهایی Production (`mgammon-duo-cpanel-deploy.zip`) وجود ندارند.** بنابراین هنگام نصب و راه‌اندازی برنامه روی هاست cPanel، به هیچ عنوان نیازی به اجرای `npm run deploy:package` یا `npm run build` نیست و تمام مراحل نصب روی هاست صرفاً از طریق بخش ۴ (بر پایه `app.cjs`، نصب وابستگی‌ها و `npm start`) انجام می‌شود.

#### ب) محتویات بسته نهایی Production (`mgammon-duo-cpanel-deploy.zip`) جهت آپلود روی هاست
فایل فشرده `mgammon-duo-cpanel-deploy.zip` از پیش بیلد شده و فقط شامل فایل‌های اجرایی و ضروری محیط عملیاتی (Production) زیر است:
- **`app.cjs`**: فایل اجرایی یکپارچه سرور Node.js + Express با فرمت CommonJS (سازگار با Node.js 22 و لودر **Phusion Passenger** در cPanel).
- **`dist/`**: پوشه کامپایل‌شده فرانت‌اند React، سرویس‌ورکر PWA (`sw.js`, `registerSW.js`)، مانیفست (`manifest.webmanifest`) و فونت محلی `Vazirmatn-VF.woff2`.
- **`public/`**: فایل‌های استاتیک پایه، آیکون‌های PWA و بنر پیش‌فرض.
- **`package.json` و `package-lock.json` (نسخه همگام Production)**: مشخصات ۷ وابستگی اجرایی سرور (`bcryptjs`, `cookie-parser`, `dotenv`, `express`, `jalaali-js`, `mysql2`, `xlsx`) سازگار با Node.js 22 که در بسته نهایی ZIP فاقد `devDependencies` و اسکریپت‌های توسعه بوده و فایل `package-lock.json` دقیقاً منطبق بر همین `package.json` تولید شده است (قابل نصب با `Run NPM Install` در cPanel، `npm install --omit=dev` یا `npm ci --omit=dev`).
- **`database/schema.sql`**: اسکریپت کامل ساختار ۱۴ جدول پایگاه داده (مورد استفاده در راه‌اندازی دیتابیس).
- **`.env.example`**: الگوی متغیرهای محیطی (فاقد هرگونه کلید یا رمز محرمانه).
- **`DEPLOYMENT_CPANEL.md`**: راهنمای جامع استقرار روی هاست.
- *(پوشه‌های `node_modules/`، `.data/`، `scripts/`، `tests/` و فایل محرمانه `.env` در این بسته قرار ندارند و وابستگی‌ها طبق بخش ۴ مستقیماً روی هاست نصب می‌شوند.)*

---

### ۴. مراحل نصب وابستگی‌ها و اجرای برنامه در cPanel (متکی بر `app.cjs` و `npm start`)
1. فایل فشرده **`mgammon-duo-cpanel-deploy.zip`** را در پوشه برنامه روی هاست (مثلاً `/home/cpaneluser/mgammon-duo`) آپلود و **Extract** کنید.
2. در cPanel از بخش **Software** وارد **Setup Node.js App** شوید و روی **Create Application** کلیک کنید.
3. مقادیر زیر را تنظیم نمایید:
   - **Node.js version**: نسخه `22.x` (پیشنهادی) یا `20.x LTS` را انتخاب کنید.
   - **Application mode**: روی `Production` قرار دهید.
   - **Application root**: مسیر پوشه برنامه روی هاست (مثلاً `mgammon-duo`).
   - **Application URL**: دامنه یا ساب‌دامنه مورد نظر خود را انتخاب کنید.
   - **Application startup file**: دقیقاً مقدار زیر را وارد کنید:
     ```text
     app.cjs
     ```
4. در بخش **Environment variables** متغیرهای زیر را تعریف کنید (یا در فایل `.env` در ریشه برنامه قرار دهید):
   ```env
   NODE_ENV=production
   SESSION_SECRET=یک_رشته_تصادفی_حداقل_۳۲_تا_۶۴_کاراکتری_امن_وارد_کنید
   DB_HOST=127.0.0.1
   DB_PORT=3306
   DB_USER=cpaneluser_mgammon
   DB_PASSWORD=رمز_عبور_دیتابیس_شما
   DB_NAME=cpaneluser_mgammon_duo
   INITIAL_MANAGER_USERNAME=manager
   INITIAL_MANAGER_PASSWORD=رمز_اولیه_امن_مدیر
   INITIAL_WORKER_USERNAME=worker
   INITIAL_WORKER_PASSWORD=رمز_اولیه_امن_کارمند
   APP_TIMEZONE=Asia/Tehran
   ```
   - **سیاست اعتبارسنجی `SESSION_SECRET` و نکته مهم `DB_PASSWORD` در cPanel:** مقدار `SESSION_SECRET` در محیط عملیاتی اجباری است و باید حداقل **۳۲ کاراکتر طول** و حداقل **۱۰ کاراکتر یکتا (Unique Characters)** داشته باشد و جزو مقادیر پیش‌فرض نباشد؛ مقدار پیشنهادی یک **رشته ۶۴ کاراکتری هگزادسیمال (`0-9` و `a-f`)** بدون فاصله و بدون علامت نقل‌قول (`"` یا `'`) است. در رابط کاربری `Setup Node.js App` سی‌پنل، مقادیر را بدون کوتیشن وارد کنید؛ اگر رمز دیتابیس (`DB_PASSWORD`) شامل کاراکتر `#` است و از فایل `.env` در ریشه برنامه استفاده می‌کنید، مقدار آن را در فایل `.env` داخل تک‌کوتیشن (`'...'`) قرار دهید تا `#` به‌عنوان کامنت تفسیر نشود.
5. روی دکمه **Create** کلیک کنید.
6. **نصب وابستگی‌ها روی هاست:** پس از ساخته شدن اپلیکیشن، در همان صفحه **Setup Node.js App** روی دکمه **Run NPM Install** کلیک کنید تا پکیج‌های موردنیاز از روی `package.json` و `package-lock.json` همگام‌شده روی هاست نصب شوند (در صورت استفاده از Terminal سی‌پنل نیز می‌توانید در محیط مجازی برنامه دستور `npm install --omit=dev` یا `npm ci --omit=dev` را اجرا کنید).
7. **اجرای برنامه:** روی دکمه **Restart** در Setup Node.js App کلیک کنید تا Passenger فایل اجرایی **`app.cjs`** را اجرا کند (پشتیبانی خودکار از پورت عددی یا UNIX socket تزریق‌شده در متغیر `PORT` توسط Passenger انجام می‌شود؛ همچنین در اجرای دستی از خط فرمان، دستور **`npm start`** مستقیماً `node app.cjs` را اجرا می‌نماید).

---

### ۵. قرار دادن لوگوی اختصاصی (`/uploads/logo.webp`)
- فایل لوگوی مجموعه در مسیر `public/uploads/logo.webp` (و پس از بیلد در `dist/uploads/logo.webp`) قرار می‌گیرد.
- اگر در هر زمان فایل لوگو جایگزین یا حذف شود، برنامه بدون هیچ خطایی نشانگر وکتور سرمه‌ای و طلایی `Mgammon` را نمایش می‌دهد.

---

### ۶. فعال‌سازی HTTPS و امنیت کوکی‌ها
1. در cPanel وارد بخش **SSL/TLS Status** شده و روی **Run AutoSSL** کلیک کنید تا گواهی SSL رایگان روی دامنه فعال شود.
2. در بخش **Domains** گزینه **Force HTTPS Redirect** را روشن کنید.
3. فعال بودن HTTPS برای کارکرد صحیح **Service Worker (قابلیت PWA)** و کوکی‌های امن `HttpOnly + Secure` الزامی است.

---

### ۷. راه‌اندازی و آزمایش PWA روی موبایل
1. آدرس HTTPS سایت را در مرورگر موبایل (Chrome در اندروید یا Safari در iOS) باز کنید.
2. در نوار بالای برنامه دکمه **«نصب وب‌اپلیکیشن»** نمایش داده می‌شود.
3. با لمس آن، برنامه با آیکون اختصاصی `Mgammon` و در حالت تمام‌صفحه (`standalone`) به صفحه اصلی گوشی اضافه می‌شود.

---

### ۸. روش تهیه نسخه پشتیبان (Backup) و بازیابی دیتابیس (Restore)

#### الف) تهیه نسخه پشتیبان (Backup)
- **روش ۱ (از طریق cPanel Backup Wizard):**
  وارد **Backup** در cPanel شوید و در بخش **Download a MySQL Database Backup** روی نام دیتابیس `cpaneluser_mgammon_duo` کلیک کنید تا فایل فشرده `.sql.gz` دانلود شود.
- **روش ۲ (از طریق خط فرمان یا Cron Job در cPanel):**
  ```bash
  mysqldump -u cpaneluser_mgammon -p'YOUR_DB_PASSWORD' --single-transaction --routines --triggers cpaneluser_mgammon_duo > backup_mgammon_$(date +%F).sql
  ```

#### ب) بازیابی نسخه پشتیبان (Restore)
- **از طریق phpMyAdmin:** دیتابیس را انتخاب کرده، وارد تب **Import** شوید و فایل `.sql` یا `.sql.gz` پشتیبان را انتخاب و بازگردانی کنید.
- **از طریق خط فرمان:**
  ```bash
  mysql -u cpaneluser_mgammon -p'YOUR_DB_PASSWORD' cpaneluser_mgammon_duo < backup_mgammon_YYYY-MM-DD.sql
  ```

---

### ۹. فهرست دقیق متغیرهای محیطی، ساخت `SESSION_SECRET` و رفع خطای `set_env_vars.py`

#### الف) جدول کامل Environment Variables
| نام متغیر | وضعیت در Production | توضیح و مقدار مجاز |
|---|---|---|
| `NODE_ENV` | الزامی | مقدار `production` (با انتخاب `Application mode: Production` در cPanel نیز اعمال می‌شود) |
| `SESSION_SECRET` | الزامی | رشته ۶۴ کاراکتری هگزادسیمال (`0-9` و `a-f`) بدون فاصله، کوتیشن یا `$` |
| `DB_HOST` | الزامی | آدرس MySQL (در cPanel معمولاً `127.0.0.1` یا `localhost`) |
| `DB_PORT` | اختیاری | پورت MySQL (پیش‌فرض `3306`؛ ثبت صریح در cPanel توصیه می‌شود) |
| `DB_NAME` | الزامی | نام کامل دیتابیس ساخته‌شده در cPanel (مثلاً `cpaneluser_mgammon_duo`) |
| `DB_USER` | الزامی | نام کاربری دیتابیس در cPanel (مثلاً `cpaneluser_mgammon`) |
| `DB_PASSWORD` | الزامی | رمز عبور کاربر دیتابیس |
| `DB_CONNECTION_LIMIT` | اختیاری | عدد بین `2` تا `50` (پیش‌فرض `10`) |
| `APP_TIMEZONE` | اختیاری | پیش‌فرض `Asia/Tehran` |
| `APP_URL` | اختیاری | نشانی کامل دامنه با HTTPS (مثلاً `https://mgammon.example.ir`) |
| `INITIAL_MANAGER_USERNAME` | اختیاری | فقط برای ساخت کاربر مدیر روی دیتابیس کاملاً خالی (پیش‌فرض `manager`) |
| `INITIAL_MANAGER_PASSWORD` | اختیاری | فقط برای ساخت کاربر مدیر روی دیتابیس کاملاً خالی (روی دیتابیس موجود تأثیری ندارد) |
| `INITIAL_WORKER_USERNAME` | اختیاری | فقط برای ساخت کاربر پرسنل روی دیتابیس کاملاً خالی (پیش‌فرض `worker`) |
| `INITIAL_WORKER_PASSWORD` | اختیاری | فقط برای ساخت کاربر پرسنل روی دیتابیس کاملاً خالی |
| `PORT` | خودکار | توسط Passenger تزریق می‌شود (عدد یا سوکت یونیکس)؛ نیاز به ثبت دستی نیست |

#### ب) چرا `set_env_vars.py` برخی متغیرها را رد (`skipped`) می‌کند؟
در cPanel هنگام انتقال متغیرهای رابط کاربری به Passenger، اسکریپت `set_env_vars.py` متغیرهایی را که شامل کاراکترهای حساس پوسته (`"`، `'`، `$`، `\`, `;`، `#`)، فاصله یا تب، خط جدید (Copy/Paste ناقص)، یا کاراکترهای غیرانگلیسی هستند رد می‌کند. در نتیجه `SESSION_SECRET` یا `DB_PASSWORD` خالی به Node.js می‌رسد.
- **راه‌حل اول:** در فیلدهای cPanel مقادیر را بدون کوتیشن، بدون فاصله ابتدا/انتها و برای `SESSION_SECRET` فقط از حروف `a-f` و ارقام `0-9` استفاده کنید.
- **راه‌حل دوم (پشتیبان امن):** اگر رمز دیتابیس کاراکتر خاص دارد یا `set_env_vars.py` آن را رد می‌کند، یک فایل `.env` در **ریشه خصوصی برنامه** (کنار `app.cjs` و هرگز داخل `public/` یا `dist/`) بسازید. برنامه ابتدا مقادیر معتبر هاست/cPanel را نگه می‌دارد و تنها متغیرهای خالی یا ردشده را به‌صورت خودکار از `.env` تکمیل می‌کند.

#### ج) روش ساخت `SESSION_SECRET` امن (با SSH و بدون SSH)
- **در کامپیوتر شخصی یا ترمینال (Node.js):**
  ```bash
  node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
  ```
- **با OpenSSL:**
  ```bash
  openssl rand -hex 32
  ```
- **بدون نیاز به SSH:** از مرورگر (Console تب Developer Tools روی یک صفحه خالی) دستور زیر را اجرا کرده و خروجی ۶۴ کاراکتری را کپی کنید:
  ```js
  Array.from(crypto.getRandomValues(new Uint8Array(32)), b => b.toString(16).padStart(2, '0')).join('')
  ```

#### د) آزمایش تنظیمات پیش از اجرا (Preflight Check بدون نیاز به SSH)
در صفحه **Setup Node.js App** در cPanel می‌توانید در بخش **Run JS script** عبارت `app.cjs --preflight` را اجرا کنید (یا در Terminal دستور `node app.cjs --preflight` را بزنید). گزارش با وضعیت‌های `PASS` / `WARNING` / `FAIL` / `NOT_CONFIGURED` بدون نمایش هیچ رمز یا Secret چاپ می‌شود.
- **نکته درباره تست نوشتن در فایل‌سیستم (`filesystem_access`):** دستور `--preflight` برای اطمینان از دسترسی نوشتن پوشه‌های `.data/private_media` و `.data/backups` (یا مسیرهای تعریف‌شده در `PRIVATE_MEDIA_DIR` و `BACKUP_DIR`) در صورت نبود پوشه آن را می‌سازد و یک فایل آزمایشی موقت `.preflight_probe_<pid>_<timestamp>` ایجاد و بلافاصله حذف می‌کند. اتصال به دیتابیس نیز صرفاً با دو کوئری خواندنی (`SELECT VERSION()` و `SHOW TABLES`) انجام می‌شود و هیچ تغییری در داده‌ها نمی‌دهد.

---

### ۱۰. روش بازگشت به نسخه قبلی (Rollback) بدون آسیب به دیتابیس
1. پیش از آپلود بسته جدید، از پوشه فعلی برنامه در **File Manager** یک کپی فشرده (یا رونوشت با نام `backup-before-update.zip` در خارج از `public_html`) تهیه کنید تا نسخه قبلی `app.cjs`، `dist/` و `.env` محفوظ بماند.
2. برنامه هرگز هنگام راه‌اندازی جداول یا داده‌های موجود دیتابیس را حذف یا بازنشانی نمی‌کند؛ با این حال پیش از هر بروزرسانی، یک نسخه پشتیبان SQL نیز مطابق بخش ۸ تهیه کنید.
3. در صورت بروز هرگونه خطا پس از دیپلوی جدید:
   - در **Setup Node.js App** برنامه را **Stop** کنید.
   - فایل‌های `app.cjs` و `dist/` جدید را پاک کرده و نسخه قبلی را از آرشیو پشتیبان جایگزین کنید (فایل `.env` و پوشه `.data/` را دست‌نخورده نگه دارید).
   - روی **Start** (یا **Restart**) کلیک کنید تا سامانه فوراً به نسخه قبلی بازگردد.

---

### ۱۱. دستورالعمل تست واقعی روی هاست cPanel (تفکیک کامل از تست‌های محیط توسعه)
موارد زیر به‌طور مستقیم به پیکربندی واقعی هاست، سیستم `CloudLinux / Passenger` و دیتابیس cPanel وابسته هستند و **صرفاً پس از آپلود روی هاست واقعی قابل تأییدند** (در محیط توسعه قابل سنجش قطعی نیستند):

1. **بررسی انتقال متغیرها توسط `set_env_vars.py`:**
   - پس از ذخیره متغیرها در رابط کاربری `Setup Node.js App` و زدن `Save`، بررسی کنید که خطای `skipped ... environment variable(s)` در لاگ Passenger ظاهر نشود.
   - در صورت مشاهده `skipped`، یا مقادیر دارای کاراکتر غیرمجاز را اصلاح کنید یا فایل `.env` را در ریشه خصوصی برنامه (کنار `app.cjs`) قرار دهید.
2. **اجرای Preflight Diagnostics روی هاست واقعی (بدون افشای Secret):**
   - از `Run JS script` یا ترمینال محیط مجازی Node.js دستور زیر را اجرا کنید:
     ```bash
     node app.cjs --preflight
     ```
   - اطمینان حاصل کنید خروجی برای `session_secret`، `db_env_vars`، `db_connectivity`، `required_modules` و `filesystem_access` برابر `PASS` باشد و هیچ موردی `FAIL` نباشد.
3. **بررسی رفتار واقعی Passenger و `PORT` روی هاست:**
   - برای تشخیص اینکه Passenger در هاست شما چه مقداری در `PORT` می‌گذارد و آیا `PhusionPassenger` فعال است، از دستور خواندنی زیر (بدون چاپ هیچ رمز یا Secret) در محیط مجازی cPanel استفاده کنید:
     ```bash
     node -e "console.log({ node: process.version, nodeEnv: process.env.NODE_ENV, passengerEnv: process.env.PASSENGER_APP_ENV, hasPhusionPassenger: typeof PhusionPassenger !== 'undefined', portKind: !process.env.PORT ? 'empty' : /^\d+$/.test(process.env.PORT) ? 'numeric' : process.env.PORT.startsWith('/') ? 'unix_socket' : 'other', secretLen: (process.env.SESSION_SECRET || '').trim().length })"
     ```
   - توجه: اگر در زمان اجرای Passenger متغیر `PORT` خالی باشد، `--preflight` وضعیت `port_config` را `WARNING` گزارش می‌کند (نه `PASS` قطعی)، زیرا برنامه به‌طور پیش‌فرض `app.listen(3000, '0.0.0.0')` را صدا می‌زند و اینکه Passenger روی هاست واقعی آن را به سوکت داخلی متصل می‌کند یا خیر فقط با تست زنده روی خود هاست قابل اثبات است.
   - اگر `portKind` برابر `'other'` بود و `app.cjs` با خطای `listen` مواجه شد، مقدار واقعی `process.env.PORT` و لاگ `stderr` Passenger باید دقیقاً بررسی شود.
4. **بررسی دسترسی HTTP/HTTPS و سلامت API روی دامنه واقعی:**
   - پس از `Restart` در Setup Node.js App، آدرس `https://your-domain/api/health` را باز کنید و مطمئن شوید `ok: true` و `dbConnected: true` برمی‌گردد.
   - ورود مدیر و کارمند را آزمایش کنید و مطمئن شوید داده‌ها و سوابق قبلی بدون تغییر باقی مانده‌اند.


